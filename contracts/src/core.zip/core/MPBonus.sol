// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/utils/math/SafeCast.sol";
import "./MPInvestment.sol";

/**
 * @title MPBonus
 * @notice Merged upline walk: referral rewards (G1-G3) + team rewards (V1-V6 level differential)
 *         + community income (admin-assigned levels).
 *         Single traversal replaces two separate walks for lower gas.
 */
abstract contract MPBonus is MPInvestment {
    using SafeCast for uint256;
    // Reward type constants for events
    uint8 internal constant REWARD_LEVEL_DIFF = 1;
    uint8 internal constant REWARD_SAME_LEVEL = 2;

    // ======================== Merged Upline Rewards ========================

    /// @dev Single upline walk distributes both referral (G1-G3) and team (V-level differential) rewards.
    ///      Replaces two separate walks, saving ~30 SLOAD per claim in deep trees.
    function _distributeUplineRewards(
        address investor,
        uint256 referralPool,
        uint256 teamPool
    ) internal override {
        address current = investor;
        uint8 gen;
        uint8 highestLevelPaid;
        bool sameLevelPaid;

        // Cache storage reads
        uint256 _referralGen1 = referralGen1;
        uint256 _referralGen2 = referralGen2;
        uint256 _referralGen3 = referralGen3;
        uint256 _sameLevelBonus = sameLevelBonus;

        for (uint256 i; i < MAX_DEPTH;) {
            address upline = _members[current].referrer;
            if (upline == address(0)) break;

            // Always count generation for referral tracking
            unchecked { gen++; }

            Member storage uplineMember = _members[upline];

            if (uplineMember.isActive && !uplineMember.isFrozen && !uplineMember.isPaused) {
                // --- Referral rewards (first 3 generations only) ---
                if (gen <= 3) {
                    uint256 unlockedGens = uplineMember.directReferralCount;
                    if (unlockedGens > 3) unlockedGens = 3;
                    if (unlockedGens >= gen) {
                        uint256 rate;
                        if (gen == 1) rate = _referralGen1;
                        else if (gen == 2) rate = _referralGen2;
                        else rate = _referralGen3;

                        uint256 reward = (referralPool * rate) / 10000;
                        if (reward > 0) {
                            _addEarningsWithCap(upline, reward);
                            emit ReferralRewardPaid(investor, upline, reward, gen);
                        }
                    }
                }

                // --- Team rewards (V-level differential, full depth) ---
                uint8 uplineLevel = uplineMember.vLevel;
                if (uplineLevel > 0) {
                    // Same-level bonus: 10% to nearest same-level ancestor (once only)
                    if (!sameLevelPaid && uplineLevel == highestLevelPaid) {
                        uint256 bonus = (teamPool * _sameLevelBonus) / 10000;
                        if (bonus > 0) {
                            _addEarningsWithCap(upline, bonus);
                            emit TeamRewardPaid(investor, upline, bonus, REWARD_SAME_LEVEL);
                            sameLevelPaid = true;
                        }
                    }

                    // Level differential
                    if (uplineLevel > highestLevelPaid) {
                        uint256 currentRate = _getVLevelRate(uplineLevel);
                        uint256 previousRate = _getVLevelRate(highestLevelPaid);
                        if (currentRate > previousRate) {
                            uint256 diffRate;
                            unchecked {
                                diffRate = currentRate - previousRate;
                            }

                            uint256 reward = (teamPool * diffRate) / 10000;
                            if (reward > 0) {
                                _addEarningsWithCap(upline, reward);
                                emit TeamRewardPaid(investor, upline, reward, REWARD_LEVEL_DIFF);
                            }
                        }

                        highestLevelPaid = uplineLevel;
                    }
                }
            }

            current = upline;
            // Early exit when both referral and team rewards are fully distributed
            if (gen >= 3 && highestLevelPaid >= 6) break;

            unchecked { ++i; }
        }
    }

    // ======================== Community Income (拍点级差) ========================

    /// @dev Admin-assigned community levels (0-5).
    ///      Rates: 20%/18%/15%/10%/5%. NOT counted in 2.5x cap.
    function _distributeCommunityIncome(address investor, uint256 orderAmount) internal override {
        address current = investor;
        uint8 highestLevelPaid;

        for (uint256 i; i < MAX_DEPTH;) {
            address upline = _members[current].referrer;
            if (upline == address(0)) break;

            Member storage uplineMember = _members[upline];

            if (uplineMember.isActive && !uplineMember.isFrozen && !uplineMember.isPaused) {
                uint8 communityLvl = uplineMember.communityLevel;

                if (communityLvl > 0 && communityLvl > highestLevelPaid) {
                    uint256 currentRate = _getCommunityRate(communityLvl);
                    uint256 previousRate = _getCommunityRate(highestLevelPaid);

                    // Higher level numbers have lower rates (L1=20%>L2=18%>...)
                    // Only pay if there's a positive differential
                    if (currentRate > previousRate) {
                        uint256 diffRate;
                        unchecked {
                            diffRate = currentRate - previousRate;
                        }

                        uint256 reward = (orderAmount * diffRate) / 10000;
                        if (reward > 0) {
                            // Community income: NOT counted in 2.5x cap
                            uplineMember.balance += reward.toUint128();
                            _communityEarned[upline] += reward;
                            emit CommunityIncomePaid(investor, upline, reward, communityLvl);
                        }
                    }

                    highestLevelPaid = communityLvl;
                }
            }

            current = upline;
            if (highestLevelPaid >= 5) break;

            unchecked { ++i; }
        }
    }

    // ======================== Rate Helpers ========================

    function _getVLevelRate(uint8 level) internal view returns (uint256) {
        if (level == 0) return 0;
        if (level > 6) return vLevelRates[5];
        return vLevelRates[level - 1];
    }

    function _getCommunityRate(uint8 level) internal view returns (uint256) {
        if (level == 0) return 0;
        if (level > 5) return communityRates[4];
        return communityRates[level - 1];
    }

    // ======================== Storage Gap ========================

    uint256[50] private __gap;
}
