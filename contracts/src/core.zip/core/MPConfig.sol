// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Context} from "@openzeppelin/contracts/utils/Context.sol";
import {ContextUpgradeable} from "@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol";
import "../utils/Ownable2StepUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "./MPStorage.sol";

/**
 * @title MPConfig
 * @notice Admin parameters (uint16 BPS) and setter functions.
 *         Uses AccessControl for role-based permissions (ERC-7201 namespaced storage).
 *         Ownable2StepUpgradeable kept for storage layout compatibility and owner() view.
 */
abstract contract MPConfig is MPStorage, Ownable2StepUpgradeable, ReentrancyGuard, Initializable, AccessControlUpgradeable {
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    // ======================== Config Parameters (BPS) ========================

    // Daily return
    uint16 public dailyReturnRate;

    // Static / Dynamic split
    uint16 public staticPercent;
    uint16 public dynamicPercent;

    // Static income distribution
    uint16 public staticToBalance;
    uint16 public staticToBurn;
    uint16 public staticToLock;

    // Referral generations
    uint16 public referralGen1;
    uint16 public referralGen2;
    uint16 public referralGen3;

    // Dynamic pool split
    uint16 public referralSharePercent;
    uint16 public teamSharePercent;

    // Cap & Fees
    uint16 public capMultiplier;
    uint16 public withdrawalFee;
    uint128 public minInvestment;
    uint128 public minWithdrawal;

    // Same-level bonus
    uint16 public sameLevelBonus;

    // V-Level thresholds (V1-V6, 6 levels)
    uint128[6] public vLevelThresholds;

    // V-Level reward rates (admin-configurable)
    uint16[6] public vLevelRates;

    // Community income rates (for admin-assigned levels 1-5)
    uint16[5] public communityRates;

    // Restart parameters
    uint16 public restartMMCompPercent;
    uint16 public restartReferralRate;
    uint16 public restartReferralCap;
    uint16 public restartMMReleaseRate;

    // Perpetual mechanism: BCK gift
    uint16 public perpetualBCKPercent;   // 20% of unreturned → BCK
    uint256 public bckPrice;              // BCK price in USDT (18 decimals, e.g. 0.5 USDT = 5e17)

    // Receiver wallet (replaces AAVE vault)
    address public receiverWallet;

    // Global pause
    bool public paused;

    // Settlement interval (default: 1 day)
    uint256 public settlementInterval;

    // ======================== Initializer ========================

    function __MPConfig_init(address initialOwner) internal onlyInitializing {
        __Ownable2Step_init(initialOwner);
        _grantRole(DEFAULT_ADMIN_ROLE, initialOwner);
        _grantRole(ADMIN_ROLE, initialOwner);

        dailyReturnRate = 80;          // 0.8%
        staticPercent = 7000;          // 70%
        dynamicPercent = 3000;         // 30%
        staticToBalance = 6000;        // 60%
        staticToBurn = 1500;           // 15%
        staticToLock = 2500;           // 25%
        referralGen1 = 2000;           // 20%
        referralGen2 = 500;            // 5%
        referralGen3 = 500;            // 5%
        referralSharePercent = 3000;   // 30% of dynamic
        teamSharePercent = 7000;       // 70% of dynamic
        capMultiplier = 250;           // 2.5x
        withdrawalFee = 500;           // 5%
        minInvestment = 100e18;
        minWithdrawal = 10e18;
        sameLevelBonus = 1000;         // 10%

        vLevelThresholds = [
            uint128(10_000e18),        // V1
            uint128(50_000e18),        // V2
            uint128(200_000e18),       // V3
            uint128(500_000e18),       // V4
            uint128(1_000_000e18),     // V5
            uint128(3_000_000e18)      // V6
        ];

        vLevelRates = [
            uint16(500),               // V1: 5%
            uint16(1000),              // V2: 10%
            uint16(1500),              // V3: 15%
            uint16(1800),              // V4: 18%
            uint16(2000),              // V5: 20%
            uint16(2200)               // V6: 22%
        ];

        communityRates = [
            uint16(2000),              // Level 1: 20%
            uint16(1800),              // Level 2: 18%
            uint16(1500),              // Level 3: 15%
            uint16(1000),              // Level 4: 10%
            uint16(500)                // Level 5: 5%
        ];

        restartMMCompPercent = 3000;   // 30%
        restartReferralRate = 1000;    // 10% (永续机制: 推荐额外补贴)
        restartReferralCap = 150;      // 1.5x
        restartMMReleaseRate = 100;    // 1% per day
        perpetualBCKPercent = 2000;    // 20% (永续机制: 按未回本赠送BCK)
        settlementInterval = 1 days;
    }

    // ======================== Context diamond resolution ========================

    function _msgSender() internal view virtual override(Context, ContextUpgradeable) returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual override(Context, ContextUpgradeable) returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual override(Context, ContextUpgradeable) returns (uint256) {
        return 0;
    }

    // ======================== Modifiers ========================

    modifier onlyAdmin() {
        _checkRole(ADMIN_ROLE, msg.sender);
        _;
    }

    modifier whenNotPaused() {
        if (paused) revert ContractPaused();
        _;
    }

    // ======================== Owner → AccessControl bridge ========================

    /// @dev Override _checkOwner so all existing onlyOwner modifiers use role-based check.
    function _checkOwner() internal view override {
        if (!hasRole(DEFAULT_ADMIN_ROLE, _msgSender())) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }

    // ======================== Admin Management ========================

    function addAdmin(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        _grantRole(ADMIN_ROLE, account);
        isAdmin[account] = true; // backward compat
        emit AdminAdded(account);
    }

    function removeAdmin(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        _revokeRole(ADMIN_ROLE, account);
        isAdmin[account] = false; // backward compat
        emit AdminRemoved(account);
    }

    // ======================== Per-Member Controls ========================

    function freezeMember(address member) external onlyAdmin {
        _members[member].isFrozen = true;
        emit ParameterUpdated("freezeMember", uint256(uint160(member)));
    }

    function unfreezeMember(address member) external onlyAdmin {
        _members[member].isFrozen = false;
        emit ParameterUpdated("unfreezeMember", uint256(uint160(member)));
    }

    function pauseMember(address member) external onlyAdmin {
        _members[member].isPaused = true;
        emit ParameterUpdated("pauseMember", uint256(uint160(member)));
    }

    function unpauseMember(address member) external onlyAdmin {
        _members[member].isPaused = false;
        emit ParameterUpdated("unpauseMember", uint256(uint160(member)));
    }

    /// @notice Admin assigns community level (0-5) to a member
    function setCommunityLevel(address member, uint8 level) external onlyAdmin {
        if (level > 5) revert InvalidLevel();
        _members[member].communityLevel = level;
    }

    /// @notice Admin manually overrides a member's V-level (0-6).
    function setMemberVLevel(address member, uint8 level) external onlyAdmin {
        if (level > 6) revert InvalidLevel();
        _members[member].vLevel = level;
        emit ParameterUpdated("setMemberVLevel", uint256(uint160(member)));
    }

    /// @notice Batch override V-levels. Max 100 per batch.
    function setMemberVLevelBatch(address[] calldata members, uint8[] calldata levels) external onlyAdmin {
        if (members.length != levels.length) revert ArrayLengthMismatch();
        if (members.length > 100) revert BatchTooLarge();
        for (uint256 i; i < members.length;) {
            if (levels[i] > 6) revert InvalidLevel();
            _members[members[i]].vLevel = levels[i];
            unchecked { ++i; }
        }
    }

    /// @notice Batch set community levels. Max 100 per batch.
    function setCommunityLevelBatch(address[] calldata members, uint8[] calldata levels) external onlyAdmin {
        if (members.length != levels.length) revert ArrayLengthMismatch();
        if (members.length > 100) revert BatchTooLarge();
        for (uint256 i; i < members.length;) {
            if (levels[i] > 5) revert InvalidLevel();
            _members[members[i]].communityLevel = levels[i];
            unchecked { ++i; }
        }
    }

    // ======================== Global Pause ========================

    function pause() external onlyAdmin {
        paused = true;
        emit Paused();
    }

    function unpause() external onlyAdmin {
        paused = false;
        emit Unpaused();
    }

    // ======================== Parameter Setters ========================

    function setDailyReturnRate(uint16 val) external onlyAdmin {
        if (val > 500) revert FeeTooHigh(); // Max 5% daily
        dailyReturnRate = val;
        emit ParameterUpdated("dailyReturnRate", val);
    }

    function setStaticDynamicSplit(uint16 _static, uint16 _dynamic) external onlyAdmin {
        if (_static + _dynamic != 10000) revert MustSumTo10000();
        staticPercent = _static;
        dynamicPercent = _dynamic;
    }

    function setStaticDistribution(uint16 _toBalance, uint16 _toBurn, uint16 _toLock) external onlyAdmin {
        if (_toBalance + _toBurn + _toLock != 10000) revert MustSumTo10000();
        staticToBalance = _toBalance;
        staticToBurn = _toBurn;
        staticToLock = _toLock;
    }

    function setReferralRates(uint16 _gen1, uint16 _gen2, uint16 _gen3) external onlyAdmin {
        referralGen1 = _gen1;
        referralGen2 = _gen2;
        referralGen3 = _gen3;
    }

    function setDynamicPoolSplit(uint16 _referral, uint16 _team) external onlyAdmin {
        if (_referral + _team != 10000) revert MustSumTo10000();
        referralSharePercent = _referral;
        teamSharePercent = _team;
    }

    function setCapMultiplier(uint16 val) external onlyAdmin {
        if (val < 100 || val > 1000) revert InvalidLevel(); // 1x to 10x
        capMultiplier = val;
    }

    function setWithdrawalFee(uint16 val) external onlyAdmin {
        if (val > 5000) revert FeeTooHigh();
        withdrawalFee = val;
    }

    function setMinInvestment(uint128 val) external onlyAdmin {
        minInvestment = val;
    }

    function setMinWithdrawal(uint128 val) external onlyAdmin {
        minWithdrawal = val;
    }

    function setSameLevelBonus(uint16 val) external onlyAdmin {
        if (val > 3000) revert FeeTooHigh(); // Max 30%
        sameLevelBonus = val;
    }

    function setVLevelThresholds(uint128[6] calldata thresholds) external onlyAdmin {
        vLevelThresholds = thresholds;
    }

    function setVLevelRates(uint16[6] calldata rates) external onlyAdmin {
        for (uint256 i = 1; i < 6; i++) {
            if (rates[i] < rates[i - 1]) revert InvalidLevel();
        }
        vLevelRates = rates;
    }

    function setCommunityRates(uint16[5] calldata rates) external onlyAdmin {
        for (uint256 i = 1; i < 5; i++) {
            if (rates[i] > rates[i - 1]) revert InvalidLevel();
        }
        communityRates = rates;
    }

    function setRestartMMCompPercent(uint16 val) external onlyAdmin {
        if (val > 5000) revert FeeTooHigh(); // Max 50%
        restartMMCompPercent = val;
    }

    function setRestartReferralRate(uint16 val) external onlyAdmin {
        restartReferralRate = val;
    }

    function setRestartReferralCap(uint16 val) external onlyAdmin {
        restartReferralCap = val;
    }

    function setRestartMMReleaseRate(uint16 val) external onlyAdmin {
        restartMMReleaseRate = val;
    }

    function setPerpetualBCKPercent(uint16 val) external onlyAdmin {
        perpetualBCKPercent = val;
        emit ParameterUpdated("perpetualBCKPercent", val);
    }

    function setBCKPrice(uint256 val) external onlyAdmin {
        if (val == 0) revert ZeroAmount();
        bckPrice = val;
        emit ParameterUpdated("bckPrice", val);
    }

    function setSettlementInterval(uint256 val) external onlyAdmin {
        if (val < 1 hours || val > 7 days) revert InvalidLevel();
        settlementInterval = val;
        emit ParameterUpdated("settlementInterval", val);
    }

    function setReceiverWallet(address _wallet) external onlyOwner {
        if (_wallet == address(0)) revert ZeroAddress();
        receiverWallet = _wallet;
        emit ParameterUpdated("receiverWallet", uint256(uint160(_wallet)));
    }

    // ======================== Storage Gap ========================

    uint256[39] private __gap;
}
