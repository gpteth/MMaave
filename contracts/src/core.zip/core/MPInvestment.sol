// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/SafeCast.sol";
import "./MPConfig.sol";
import "../external/PancakeSwapper.sol";

/**
 * @title MPInvestment
 * @notice invest(), DSR-based claimDailyReturn(), V-level upgrade logic.
 *         Uses Discrete Staking Rewards (Synthetix pattern) for O(1) reward calculation.
 *         Auto-settlement: epochs derived lazily from block.timestamp, no manual settle() required.
 */
abstract contract MPInvestment is MPConfig {
    using SafeERC20 for IERC20;
    using SafeCast for uint256;

    /// @custom:oz-upgrades-unsafe-allow state-variable-immutable
    IERC20 public immutable usdt;
    /// @custom:oz-upgrades-unsafe-allow state-variable-immutable
    PancakeSwapper public immutable pancakeSwapper;
    /// @custom:oz-upgrades-unsafe-allow state-variable-immutable
    IERC20 public immutable mmToken;
    /// @custom:oz-upgrades-unsafe-allow state-variable-immutable
    IERC20 public immutable bckToken;

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor(address _usdt, address _pancakeSwapper, address _mmToken, address _bckToken) {
        usdt = IERC20(_usdt);
        pancakeSwapper = PancakeSwapper(_pancakeSwapper);
        mmToken = IERC20(_mmToken);
        bckToken = IERC20(_bckToken);
    }

    // ======================== DSR Core ========================

    /// @dev Current epoch derived lazily from block.timestamp (auto-settlement).
    function _currentEpoch() internal view returns (uint256) {
        if (genesisTimestamp == 0) return currentEpoch; // pre-migration fallback
        return (block.timestamp - genesisTimestamp) / settlementInterval;
    }

    /// @dev Accumulated reward per token (scaled 1e18). Grows by dailyReturnRate * 1e14 per epoch.
    function _currentRewardPerToken() internal view returns (uint256) {
        uint256 epoch = _currentEpoch();
        if (epoch <= lastUpdateEpoch) return rewardPerTokenStored;
        return rewardPerTokenStored + (epoch - lastUpdateEpoch) * uint256(dailyReturnRate) * 1e14;
    }

    /// @dev Update global accumulator to current epoch.
    function _updateGlobalReward() internal {
        rewardPerTokenStored = _currentRewardPerToken();
        lastUpdateEpoch = _currentEpoch();
    }

    /// @dev Lazy migration: calculate _activeStake from old orders for pre-DSR users.
    ///      Only triggers for users who have orders but no _activeStake set (pre-upgrade state).
    function _ensureMigrated(address user) internal {
        if (_userRewardPerTokenPaid[user] == 0
            && _isMemberRegistered[user]
            && _orders[user].length > 0
            && _activeStake[user] == 0
        ) {
            Order[] storage orders = _orders[user];
            uint128 stake;
            for (uint256 i; i < orders.length;) {
                if (orders[i].isActive) {
                    stake += orders[i].amount;
                }
                unchecked { ++i; }
            }
            if (stake > 0) {
                _activeStake[user] = stake;
            }
            _userRewardPerTokenPaid[user] = rewardPerTokenStored;
        }
    }

    /// @dev Flush pending rewards and snapshot current rewardPerToken.
    function _updateReward(address user) internal {
        _updateGlobalReward();
        _ensureMigrated(user);
        uint128 stake = _activeStake[user];
        if (stake > 0) {
            _pendingRewards[user] +=
                uint256(stake) * (rewardPerTokenStored - _userRewardPerTokenPaid[user]) / 1e18;
        }
        _userRewardPerTokenPaid[user] = rewardPerTokenStored;
    }

    // ======================== Invest ========================

    function invest(uint256 amount, address referrer) external nonReentrant whenNotPaused {
        address user = msg.sender;

        if (amount < minInvestment) revert BelowMinInvestment();
        if (amount % 100e18 != 0) revert NotMultipleOf100();

        Member storage member = _members[user];
        if (member.isFrozen) revert AccountFrozen();
        if (member.isPaused) revert AccountPaused();

        // Transfer USDT from user
        usdt.safeTransferFrom(user, address(this), amount);

        // Register if new
        if (!_isMemberRegistered[user]) {
            _registerMember(user, referrer);
        }

        // Re-activate restarted user (relationships & levels preserved)
        if (member.isRestarted) {
            member.isActive = true;
        }

        // DSR: flush pending before stake change
        _updateReward(user);
        _activeStake[user] += amount.toUint128();

        // Create order (historical record for display/restart)
        uint256 orderIndex = _orders[user].length;
        _orders[user].push(Order({
            amount: amount.toUint128(),
            totalReturned: 0,
            createdAt: block.timestamp.toUint32(),
            lastClaimedAt: 0,
            isActive: true,
            lastClaimedEpoch: uint32(_currentEpoch())
        }));
        member.totalInvested += amount.toUint128();
        emit OrderCreated(user, amount, orderIndex);

        // Update team performance up the chain
        _updateTeamPerformance(user, amount);

        // Transfer to receiver wallet
        usdt.safeTransfer(receiverWallet, amount);

        // Distribute community income (拍点级差)
        _distributeCommunityIncome(user, amount);

        // Handle restart referral compensation if referrer is restarted
        _handleRestartReferralCompensation(user, amount);

        emit Invested(user, amount, referrer);
    }

    // ======================== Settlement (backward compat) ========================

    /// @notice Update global accumulator. With DSR this is optional — epochs auto-advance.
    function settle() external {
        _updateGlobalReward();
        // Sync legacy state variables for backward compatibility
        currentEpoch = _currentEpoch();
        lastSettledAt = block.timestamp;
        emit EpochSettled(currentEpoch, block.timestamp);
    }

    // ======================== Daily Return (DSR-based, O(1)) ========================

    function claimDailyReturn(address user) external nonReentrant whenNotPaused {
        if (msg.sender != user && !hasRole(ADMIN_ROLE, msg.sender)) revert NotAdmin();
        _claimDailyReturn(user);
    }

    function batchClaimDailyReturn(address[] calldata users) external nonReentrant whenNotPaused {
        if (!hasRole(ADMIN_ROLE, msg.sender)) revert NotAdmin();
        if (users.length > 100) revert BatchTooLarge();
        for (uint256 i; i < users.length;) {
            _claimDailyReturnSafe(users[i]);
            unchecked { ++i; }
        }
    }

    /// @dev Safe version that skips inactive/frozen/paused users (for batch and auto-claim).
    function _claimDailyReturnSafe(address user) internal {
        Member storage member = _members[user];
        if (!member.isActive || member.isFrozen || member.isPaused) return;
        if (_activeStake[user] == 0 && _pendingRewards[user] == 0) return;
        _claimDailyReturn(user);
    }

    /// @dev O(1) DSR claim: calculate pending, apply 2.5x cap, split static/dynamic.
    function _claimDailyReturn(address user) internal {
        Member storage member = _members[user];
        if (!member.isActive) revert NotActive();
        if (member.isFrozen) revert AccountFrozen();
        if (member.isPaused) revert AccountPaused();

        _updateReward(user);

        uint256 reward = _pendingRewards[user];
        if (reward == 0) return;

        // Per-user cap on raw daily return (replaces per-order cap)
        uint256 cap = uint256(member.totalInvested) * capMultiplier / 100;
        uint256 used = _totalRawReturn[user];
        if (used >= cap) {
            _pendingRewards[user] = 0;
            _activeStake[user] = 0;
            return;
        }

        uint256 remaining;
        unchecked { remaining = cap - used; }

        if (reward > remaining) {
            reward = remaining;
            _activeStake[user] = 0; // fully capped
            emit UserCapped(user, used + reward);
        }

        _pendingRewards[user] = 0;
        _totalRawReturn[user] = used + reward;

        // Split: static / dynamic
        uint256 staticAmount = (reward * staticPercent) / 10000;
        uint256 dynamicAmount = reward - staticAmount;

        _processStaticIncome(user, staticAmount);

        if (dynamicAmount > 0) {
            _distributeUplineRewards(
                user,
                (dynamicAmount * referralSharePercent) / 10000,
                (dynamicAmount * teamSharePercent) / 10000
            );
        }

        emit DailyReturnClaimed(user, reward);
    }

    // ======================== Static Income ========================

    function _processStaticIncome(address user, uint256 amount) internal {
        uint256 _staticToBalance = staticToBalance;
        uint256 _staticToBurn = staticToBurn;
        address _receiverWallet = receiverWallet;

        uint256 toBalance = (amount * _staticToBalance) / 10000;
        uint256 toBurn = (amount * _staticToBurn) / 10000;
        uint256 toLock = amount - toBalance - toBurn;

        if (toBalance > 0) {
            _addEarningsWithCap(user, toBalance);
        }

        address _swapperAddr = address(pancakeSwapper);
        uint256 swapperTotal = toBurn + toLock;
        if (swapperTotal > 0) {
            usdt.safeTransferFrom(_receiverWallet, _swapperAddr, swapperTotal);
            if (toBurn > 0) {
                pancakeSwapper.buyAndBurn(toBurn, 0);
            }
            if (toLock > 0) {
                pancakeSwapper.buyForLock(toLock, user, 0);
            }
        }
    }

    // ======================== Registration ========================

    function _registerMember(address user, address referrer) internal {
        if (user == referrer) revert CannotReferSelf();
        if (referrer != address(0) && !_isMemberRegistered[referrer]) revert ReferrerNotRegistered();

        Member storage member = _members[user];
        member.referrer = referrer;
        member.isActive = true;
        _isMemberRegistered[user] = true;
        _allMembers.push(user);

        if (referrer != address(0)) {
            _directReferrals[referrer].push(user);
            _members[referrer].directReferralCount++;
        }

        emit MemberRegistered(user, referrer);
    }

    // ======================== Team Performance ========================

    function _updateTeamPerformance(address user, uint256 amount) internal {
        address current = user;

        for (uint256 i; i < MAX_DEPTH;) {
            address upline = _members[current].referrer;
            if (upline == address(0)) break;

            uint256 newTeamPerf = _teamPerformance[upline] + amount;
            _teamPerformance[upline] = newTeamPerf;

            _branchPerformance[upline][current] += amount;

            uint8 currentVLevel = _members[upline].vLevel;
            if (currentVLevel < 6 && newTeamPerf >= vLevelThresholds[currentVLevel]) {
                _updateVLevel(upline);
            }

            current = upline;
            unchecked { ++i; }
        }
    }

    // ======================== V-Level Upgrade ========================

    function _updateVLevel(address user) internal {
        Member storage member = _members[user];
        uint8 currentLevel = member.vLevel;

        for (uint8 targetLevel = currentLevel + 1; targetLevel <= 6; targetLevel++) {
            uint256 smallZone = _getSmallZonePerformance(user);
            if (smallZone < vLevelThresholds[targetLevel - 1]) break;

            if (targetLevel >= 2) {
                if (!_checkBranchVLevelCondition(user, targetLevel - 1)) break;
            }

            member.vLevel = targetLevel;
            _highestVLevelInSubtree[user] = targetLevel;
            emit VLevelUpgraded(user, currentLevel, targetLevel);
        }
    }

    function _getSmallZonePerformance(address user) internal view returns (uint256) {
        address[] storage refs = _directReferrals[user];
        uint256 total = _teamPerformance[user];
        uint256 maxBranch;
        uint256 len = refs.length;

        for (uint256 i; i < len;) {
            uint256 branchPerf = _branchPerformance[user][refs[i]];
            if (branchPerf > maxBranch) {
                maxBranch = branchPerf;
            }
            unchecked { ++i; }
        }

        return total > maxBranch ? total - maxBranch : 0;
    }

    function _checkBranchVLevelCondition(address user, uint8 requiredLevel) internal view returns (bool) {
        address[] storage refs = _directReferrals[user];
        uint256 qualifiedBranches;
        uint256 len = refs.length;

        for (uint256 i; i < len;) {
            if (_getHighestVLevelInBranch(refs[i]) >= requiredLevel) {
                qualifiedBranches++;
                if (qualifiedBranches >= 2) return true;
            }
            unchecked { ++i; }
        }

        return false;
    }

    function _getHighestVLevelInBranch(address root) internal view returns (uint8) {
        uint8 highest = _members[root].vLevel;
        uint8 cached = _highestVLevelInSubtree[root];
        return cached > highest ? cached : highest;
    }

    // ======================== Earnings with 2.5x Cap ========================

    function _addEarningsWithCap(address user, uint256 amount) internal {
        Member storage member = _members[user];
        uint256 cap = (uint256(member.totalInvested) * capMultiplier) / 100;

        if (member.totalEarned >= cap) return;

        uint256 remaining;
        unchecked {
            remaining = cap - member.totalEarned;
        }
        uint256 actual = amount > remaining ? remaining : amount;

        if (actual > 0) {
            member.balance += actual.toUint128();
            member.totalEarned += actual.toUint128();
            emit BalanceUpdated(user, member.balance);
        }
    }

    // ======================== Virtual functions ========================

    function _distributeUplineRewards(address investor, uint256 referralPool, uint256 teamPool) internal virtual;
    function _distributeCommunityIncome(address investor, uint256 orderAmount) internal virtual;
    function _handleRestartReferralCompensation(address referredUser, uint256 investAmount) internal virtual;
}
