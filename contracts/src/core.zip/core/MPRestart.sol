// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/SafeCast.sol";
import "./MPBonus.sol";

/**
 * @title MPRestart
 * @notice Restart mechanism: individual/batch restart, MM compensation, referral compensation.
 */
abstract contract MPRestart is MPBonus {
    using SafeERC20 for IERC20;
    using SafeCast for uint256;

    // ======================== Restart ========================

    /// @notice Restart a single user's account. Admin only.
    function restart(address user) external onlyAdmin {
        _restartUser(user);
    }

    /// @notice Batch restart for specified users. Admin only. Max 100 per batch.
    function globalRestart(address[] calldata users) external onlyAdmin {
        if (users.length > 100) revert BatchTooLarge();
        for (uint256 i; i < users.length;) {
            if (_members[users[i]].isActive) {
                _restartUser(users[i]);
            }
            unchecked { ++i; }
        }
        emit GlobalRestartExecuted(users.length);
    }

    function _restartUser(address user) internal {
        Member storage member = _members[user];
        if (!member.isActive && member.totalInvested == 0) revert NothingToRestart();

        // Calculate unreturned capital: totalInvested - totalWithdrawn
        uint128 unreturned;
        if (member.totalInvested > member.totalWithdrawn) {
            unchecked {
                unreturned = member.totalInvested - member.totalWithdrawn;
            }
        }
        // Positive (已回本) → ignore; only negative (未回本) gets compensation

        // Record restart state
        _restartInfo[user] = RestartInfo({
            unreturnedCapital: unreturned,
            referralEarned: 0
        });

        // MM compensation: 30% of unreturned as locked MM
        uint128 mmCompAmount = ((uint256(unreturned) * restartMMCompPercent) / 10000).toUint128();
        _tokenLocks[user] = TokenLock({
            amount: mmCompAmount,
            originalAmount: mmCompAmount,
            lockedAt: block.timestamp.toUint32()
        });

        // 永续机制: BCK锁仓 = unreturned × perpetualBCKPercent / 10000 ÷ bckPrice
        // BCK转入锁仓帐户，帐户有活跃订单后开始释放
        if (unreturned > 0 && bckPrice > 0 && perpetualBCKPercent > 0) {
            uint256 bckUsdtValue = (uint256(unreturned) * perpetualBCKPercent) / 10000;
            uint256 bckAmount = (bckUsdtValue * 1e18) / bckPrice;
            if (bckAmount > 0) {
                _bckLocks[user] = BCKLock({
                    amount: bckAmount.toUint128(),
                    originalAmount: bckAmount.toUint128(),
                    lockedAt: block.timestamp.toUint32()
                });
                emit BCKLocked(user, bckAmount, unreturned);
            }
        }

        // Mark as restarted — relationships (referrer) and levels (vLevel, communityLevel) stay unchanged
        member.isRestarted = true;
        member.isActive = false;
        member.balance = 0;
        member.totalEarned = 0;
        // 全部清0重新开始: reset investment totals
        member.totalInvested = 0;
        member.totalWithdrawn = 0;

        // Clear all orders
        delete _orders[user];

        // Reset DSR state
        _updateReward(user);
        _activeStake[user] = 0;
        _pendingRewards[user] = 0;
        _totalRawReturn[user] = 0;

        emit AccountRestarted(user, unreturned);
    }

    // ======================== Restart Referral Compensation ========================

    /// @dev Called during invest() when the investor's referrer is restarted.
    ///      永续机制: Earns 10% of new investment, capped at 1.5x unreturned.
    function _handleRestartReferralCompensation(address referredUser, uint256 investAmount) internal override {
        address restartedUser = _members[referredUser].referrer;
        if (restartedUser == address(0)) return;
        if (!_members[restartedUser].isRestarted) return;

        RestartInfo storage info = _restartInfo[restartedUser];
        uint256 cap = (uint256(info.unreturnedCapital) * restartReferralCap) / 100;
        if (info.referralEarned >= cap) return;

        uint256 compensation = (investAmount * restartReferralRate) / 10000;
        uint256 remaining;
        unchecked {
            remaining = cap - info.referralEarned;
        }
        if (compensation > remaining) {
            compensation = remaining;
        }

        if (compensation > 0) {
            _members[restartedUser].balance += compensation.toUint128();
            info.referralEarned += compensation.toUint128();
            emit ReferralCompensationClaimed(restartedUser, referredUser, compensation);
        }
    }

    // ======================== BCK Lock Release ========================

    /// @notice Claim locked BCK. Only releases when user has active orders.
    function claimBCKRelease(address user) external nonReentrant whenNotPaused {
        if (msg.sender != user && !hasRole(ADMIN_ROLE, msg.sender)) revert NotAdmin();

        BCKLock storage lock = _bckLocks[user];
        if (lock.originalAmount == 0) revert NoBCKToClaim();
        if (lock.amount == 0) revert NoBCKToClaim();

        // BCK only releases when account has active orders
        if (!_hasActiveOrders(user)) revert NoActiveOrders();

        uint256 daysSinceLock = (block.timestamp - lock.lockedAt) / 1 days;
        if (daysSinceLock == 0) revert TooEarly();

        // Linear release: same rate as MM (restartMMReleaseRate per day)
        uint256 maxReleasable = (uint256(lock.originalAmount) * restartMMReleaseRate * daysSinceLock) / 10000;
        if (maxReleasable > lock.originalAmount) {
            maxReleasable = lock.originalAmount;
        }

        uint256 alreadyClaimed = uint256(lock.originalAmount) - uint256(lock.amount);
        if (maxReleasable <= alreadyClaimed) revert TooEarly();

        uint256 releaseAmount;
        unchecked {
            releaseAmount = maxReleasable - alreadyClaimed;
        }

        lock.amount -= releaseAmount.toUint128();

        if (releaseAmount > 0) {
            bckToken.safeTransfer(user, releaseAmount);
            emit BCKReleased(user, releaseAmount);
        }
    }

    /// @dev Check if user has active stake (DSR) or legacy active orders.
    function _hasActiveOrders(address user) internal view returns (bool) {
        if (_activeStake[user] > 0) return true;
        // Fallback: check legacy orders for pre-migration users
        Order[] storage userOrders = _orders[user];
        for (uint256 i; i < userOrders.length;) {
            if (userOrders[i].isActive) return true;
            unchecked { ++i; }
        }
        return false;
    }

    // ======================== MM Compensation Claim ========================

    /// @notice Claim MM token compensation. Linear release based on originalAmount.
    function claimMMCompensation(address user) external nonReentrant whenNotPaused {
        if (msg.sender != user && !hasRole(ADMIN_ROLE, msg.sender)) revert NotAdmin();
        if (!_members[user].isRestarted) revert NotRestarted();

        TokenLock storage lock = _tokenLocks[user];
        if (lock.originalAmount == 0) revert NoMMToClaim();
        if (lock.amount == 0) revert NoMMToClaim();

        uint256 daysSinceLock = (block.timestamp - lock.lockedAt) / 1 days;
        if (daysSinceLock == 0) revert TooEarly();

        // Linear release: maxReleasable based on total elapsed days from lock start
        // totalClaimed so far = originalAmount - amount (remaining)
        uint256 maxReleasable = (uint256(lock.originalAmount) * restartMMReleaseRate * daysSinceLock) / 10000;
        if (maxReleasable > lock.originalAmount) {
            maxReleasable = lock.originalAmount;
        }

        uint256 alreadyClaimed = uint256(lock.originalAmount) - uint256(lock.amount);
        if (maxReleasable <= alreadyClaimed) revert TooEarly();

        uint256 releaseAmount;
        unchecked {
            releaseAmount = maxReleasable - alreadyClaimed;
        }

        lock.amount -= releaseAmount.toUint128();

        if (releaseAmount > 0) {
            mmToken.safeTransfer(user, releaseAmount);
            emit MMCompensationClaimed(user, releaseAmount);
        }
    }

    // ======================== Storage Gap ========================

    uint256[50] private __gap;
}
