// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title MPStorage
 * @notice Packed structs, mappings, custom errors, and events for MemePlus.
 */
abstract contract MPStorage {
    // ======================== Constants ========================

    uint256 internal constant MAX_DEPTH = 30;

    // ======================== Packed Structs ========================

    /// @dev 4 storage slots
    struct Member {
        // Slot 1: address(20) + uint8(1) + uint8(1) + bool(1)*4 = 26 bytes
        address referrer;
        uint8 vLevel;
        uint8 communityLevel; // admin-assigned, 0-5
        bool isActive;
        bool isFrozen;
        bool isPaused;
        bool isRestarted;
        // Slot 2
        uint128 totalInvested;
        uint128 totalWithdrawn;
        // Slot 3
        uint128 balance;
        uint128 totalEarned;
        // Slot 4
        uint32 directReferralCount;
        uint32 lastClaimTimestamp;
    }

    /// @dev 2 storage slots
    struct Order {
        // Slot 1
        uint128 amount;
        uint128 totalReturned;
        // Slot 2
        uint32 createdAt;
        uint32 lastClaimedAt;   // legacy: timestamp for pre-upgrade orders; 0 = migrated to epoch-based
        bool isActive;
        uint32 lastClaimedEpoch; // epoch when last claimed (0 for legacy orders until first claim)
    }

    struct RestartInfo {
        uint128 unreturnedCapital;
        uint128 referralEarned;
    }

    struct TokenLock {
        uint128 amount;          // MM tokens remaining to claim
        uint128 originalAmount;  // original MM tokens locked (for linear release calc)
        uint32 lockedAt;         // timestamp
    }

    struct BCKLock {
        uint128 amount;          // BCK tokens remaining to release
        uint128 originalAmount;  // original BCK tokens locked
        uint32 lockedAt;         // timestamp
    }

    // ======================== State Variables ========================

    mapping(address => Member) internal _members;
    mapping(address => Order[]) internal _orders;
    mapping(address => address[]) internal _directReferrals;
    mapping(address => uint256) internal _teamPerformance;
    mapping(address => mapping(address => uint256)) internal _branchPerformance;
    mapping(address => RestartInfo) internal _restartInfo;
    mapping(address => TokenLock) internal _tokenLocks;
    mapping(address => BCKLock) internal _bckLocks;

    // Cached highest V-level in subtree for efficient upgrade checks
    mapping(address => uint8) internal _highestVLevelInSubtree;

    // Community income tracking (not subject to 2.5x cap)
    mapping(address => uint256) internal _communityEarned;

    // All registered members
    address[] internal _allMembers;
    mapping(address => bool) internal _isMemberRegistered;

    // Epoch-based settlement
    uint256 public currentEpoch;
    uint256 public lastSettledAt;

    // Admin roles
    mapping(address => bool) public isAdmin;

    // ======================== DSR (Discrete Staking Rewards) ========================

    /// @dev Global reward accumulator, scaled by 1e18. Increases by dailyReturnRate*1e14 per epoch.
    uint256 public rewardPerTokenStored;
    /// @dev Last epoch at which rewardPerTokenStored was updated.
    uint256 public lastUpdateEpoch;
    /// @dev Timestamp of epoch 0 — epochs are derived as (block.timestamp - genesisTimestamp) / interval.
    uint256 public genesisTimestamp;
    /// @dev Per-user snapshot of rewardPerTokenStored at last interaction.
    mapping(address => uint256) internal _userRewardPerTokenPaid;
    /// @dev Per-user total active investment (sum of all active order amounts).
    mapping(address => uint128) internal _activeStake;
    /// @dev Per-user buffered unclaimed rewards (raw daily return, pre-split).
    mapping(address => uint256) internal _pendingRewards;
    /// @dev Per-user total raw daily return consumed (for 2.5x cap).
    mapping(address => uint256) internal _totalRawReturn;

    // ======================== Custom Errors ========================

    error NotOwner();
    error NotAdmin();
    error NotActive();
    error AccountFrozen();
    error AccountPaused();
    error AlreadyRegistered();
    error CannotReferSelf();
    error NotRegistered();
    error BelowMinInvestment();
    error NotMultipleOf100();
    error BelowMinWithdrawal();
    error NotMultipleOf10();
    error InsufficientBalance();
    error ZeroAmount();
    error ZeroAddress();
    error NothingToRestart();
    error NotRestarted();
    error NoMMToClaim();
    error NoBCKToClaim();
    error NoActiveOrders();
    error TooEarly();
    error InvalidLevel();
    error ArrayLengthMismatch();
    error FeeTooHigh();
    error MustSumTo10000();
    error ContractPaused();
    error InvalidIndex();
    error BatchTooLarge();
    error ReferrerNotRegistered();

    // ======================== Events ========================

    event MemberRegistered(address indexed user, address indexed referrer);
    event Invested(address indexed user, uint256 amount, address indexed referrer);
    event OrderCreated(address indexed user, uint256 amount, uint256 index);
    event OrderCapped(address indexed user, uint256 orderIndex);
    event UserCapped(address indexed user, uint256 totalRawReturn);
    event DailyReturnClaimed(address indexed user, uint256 totalReturn);
    event BalanceUpdated(address indexed user, uint256 newBalance);
    event ReferralRewardPaid(address indexed investor, address indexed referrer, uint256 amount, uint8 generation);
    event TeamRewardPaid(address indexed investor, address indexed ancestor, uint256 amount, uint8 rewardType);
    event CommunityIncomePaid(address indexed investor, address indexed ancestor, uint256 amount, uint8 level);
    event VLevelUpgraded(address indexed user, uint8 oldLevel, uint8 newLevel);
    event Withdrawn(address indexed user, uint256 grossAmount, uint256 fee, uint256 netAmount);
    event AccountRestarted(address indexed user, uint256 unreturnedCapital);
    event ReferralCompensationClaimed(address indexed restartedUser, address indexed referredUser, uint256 amount);
    event MMCompensationClaimed(address indexed user, uint256 amount);
    event BCKLocked(address indexed user, uint256 bckAmount, uint256 unreturnedCapital);
    event BCKReleased(address indexed user, uint256 amount);
    event GlobalRestartExecuted(uint256 count);
    event AdminAdded(address indexed account);
    event AdminRemoved(address indexed account);
    event ParameterUpdated(string name, uint256 value);
    event EpochSettled(uint256 indexed epoch, uint256 timestamp);
    event Paused();
    event Unpaused();

    // ======================== Storage Gap ========================

    uint256[28] private __gap;
}
