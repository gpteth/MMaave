// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/SafeCast.sol";
import "@openzeppelin/contracts/proxy/utils/UUPSUpgradeable.sol";
import "./MPRestart.sol";


/**
 * @title MemePlus
 * @notice Main entry point: withdraw, views, emergency functions.
 *         Inherits full chain: MPStorage -> MPConfig -> MPInvestment -> MPBonus -> MPRestart -> MemePlus
 *         Deployed behind an ERC1967 UUPS proxy.
 *
 *         V6: DSR (Discrete Staking Rewards) — O(1) reward calculation, auto-settlement.
 */
contract MemePlus is MPRestart, UUPSUpgradeable {
    using SafeERC20 for IERC20;
    using SafeCast for uint256;

    uint16 public constant VERSION = 6;

    address public feeCollector;

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor(
        address _usdt,
        address _pancakeSwapper,
        address _mmToken,
        address _bckToken
    )
        MPInvestment(_usdt, _pancakeSwapper, _mmToken, _bckToken)
    {
        _disableInitializers();
    }

    function initialize(address _owner, address _feeCollector, address _receiverWallet) external initializer {
        __MPConfig_init(_owner);
        feeCollector = _feeCollector;
        receiverWallet = _receiverWallet;
    }

    /// @notice V3 migration: set up AccessControl roles for existing owner and admins.
    function initializeV3(address[] calldata admins) external reinitializer(5) {
        address currentOwner = owner();
        _grantRole(DEFAULT_ADMIN_ROLE, currentOwner);
        _grantRole(ADMIN_ROLE, currentOwner);
        for (uint256 i; i < admins.length;) {
            _grantRole(ADMIN_ROLE, admins[i]);
            unchecked { ++i; }
        }
    }

    /// @notice V5 migration: activate epoch-based discrete staking rewards.
    function initializeV5() external reinitializer(6) {
        lastSettledAt = block.timestamp;
        settlementInterval = 1 days;
    }

    /// @notice V6 migration: activate DSR (Discrete Staking Rewards) with auto-settlement.
    function initializeV6() external reinitializer(7) {
        // Ensure settlement interval is set (may not have been if initializeV5 was skipped)
        if (settlementInterval == 0) {
            settlementInterval = 1 days;
        }

        // Derive genesis so _currentEpoch() equals the old currentEpoch at this moment
        if (lastSettledAt > 0 && currentEpoch > 0) {
            genesisTimestamp = lastSettledAt - currentEpoch * settlementInterval;
        } else {
            genesisTimestamp = block.timestamp;
        }
        // Initialize accumulator consistent with historical epochs
        rewardPerTokenStored = _currentEpoch() * uint256(dailyReturnRate) * 1e14;
        lastUpdateEpoch = _currentEpoch();
    }

    // ======================== UUPS ========================

    function _authorizeUpgrade(address) internal override onlyOwner {}

    // ======================== Register ========================

    /// @notice Register and bind a referrer without investing.
    function register(address referrer) external nonReentrant whenNotPaused {
        if (_isMemberRegistered[msg.sender]) revert AlreadyRegistered();
        _registerMember(msg.sender, referrer);
    }

    // ======================== Withdraw ========================

    function withdraw(uint256 amount) external nonReentrant whenNotPaused {
        address user = msg.sender;

        if (amount < minWithdrawal) revert BelowMinWithdrawal();
        if (amount % 10e18 != 0) revert NotMultipleOf10();

        Member storage member = _members[user];
        if (!member.isActive) revert NotActive();
        if (member.isFrozen) revert AccountFrozen();
        if (member.isPaused) revert AccountPaused();

        // Auto-claim pending DSR rewards before withdrawal
        _claimDailyReturnSafe(user);

        if (member.balance < amount.toUint128()) revert InsufficientBalance();

        // Calculate fee
        uint256 fee = (amount * withdrawalFee) / 10000;
        uint256 netAmount = amount - fee;

        // Deduct from balance
        member.balance -= amount.toUint128();
        member.totalWithdrawn += amount.toUint128();

        // Transfer from receiver wallet
        if (netAmount > 0) {
            usdt.safeTransferFrom(receiverWallet, user, netAmount);
        }
        if (fee > 0 && feeCollector != address(0)) {
            usdt.safeTransferFrom(receiverWallet, feeCollector, fee);
        }

        emit Withdrawn(user, amount, fee, netAmount);
    }

    // ======================== Fee Collector ========================

    function setFeeCollector(address _collector) external onlyOwner {
        if (_collector == address(0)) revert ZeroAddress();
        feeCollector = _collector;
    }

    // ======================== Emergency ========================

    function rescueTokens(address token, uint256 amount) external onlyOwner {
        IERC20(token).safeTransfer(owner(), amount);
    }

    // ======================== View Functions ========================

    function getMemberInfo(address user) external view returns (
        address referrer,
        uint8 vLevel,
        uint8 communityLevel,
        bool isActive,
        bool isFrozen,
        bool isPaused,
        bool isRestarted,
        uint256 totalInvested,
        uint256 totalWithdrawn,
        uint256 balance,
        uint256 totalEarned,
        uint256 directReferralCount
    ) {
        Member storage m = _members[user];
        return (
            m.referrer,
            m.vLevel,
            m.communityLevel,
            m.isActive,
            m.isFrozen,
            m.isPaused,
            m.isRestarted,
            m.totalInvested,
            m.totalWithdrawn,
            m.balance,
            m.totalEarned,
            m.directReferralCount
        );
    }

    /// @notice Get pending DSR rewards (raw daily return, pre-split). Pure view, no state change.
    function getPendingRewards(address user) external view returns (uint256) {
        uint256 rpt = _currentRewardPerToken();
        uint256 paid = _userRewardPerTokenPaid[user];
        uint128 stake = _activeStake[user];

        // Lazy migration estimate: if not migrated, calculate from orders
        if (paid == 0 && _isMemberRegistered[user] && stake == 0) {
            Order[] storage orders = _orders[user];
            for (uint256 i; i < orders.length;) {
                if (orders[i].isActive) stake += orders[i].amount;
                unchecked { ++i; }
            }
            paid = rewardPerTokenStored; // would be set during migration
        }

        uint256 pending = _pendingRewards[user];
        if (stake > 0 && rpt > paid) {
            pending += uint256(stake) * (rpt - paid) / 1e18;
        }

        // Apply 2.5x cap
        Member storage m = _members[user];
        uint256 cap = uint256(m.totalInvested) * capMultiplier / 100;
        uint256 used = _totalRawReturn[user];
        if (used >= cap) return 0;
        uint256 remaining;
        unchecked { remaining = cap - used; }
        return pending > remaining ? remaining : pending;
    }

    /// @notice Get DSR state for a user.
    function getDSRInfo(address user) external view returns (
        uint128 activeStake,
        uint256 pendingRewards,
        uint256 totalRawReturn,
        uint256 userRewardPerTokenPaid
    ) {
        return (
            _activeStake[user],
            _pendingRewards[user],
            _totalRawReturn[user],
            _userRewardPerTokenPaid[user]
        );
    }

    function getOrders(address user) external view returns (Order[] memory) {
        return _orders[user];
    }

    function getDirectReferrals(address user) external view returns (address[] memory) {
        return _directReferrals[user];
    }

    function getBranchPerformance(address user, address directRef) external view returns (uint256) {
        return _branchPerformance[user][directRef];
    }

    function getRestartInfo(address user) external view returns (uint128 unreturnedCapital, uint128 referralEarned) {
        RestartInfo storage info = _restartInfo[user];
        return (info.unreturnedCapital, info.referralEarned);
    }

    function getTokenLock(address user) external view returns (uint128 amount, uint128 originalAmount, uint32 lockedAt) {
        TokenLock storage lock = _tokenLocks[user];
        return (lock.amount, lock.originalAmount, lock.lockedAt);
    }

    function getBCKLock(address user) external view returns (uint128 amount, uint128 originalAmount, uint32 lockedAt) {
        BCKLock storage lock = _bckLocks[user];
        return (lock.amount, lock.originalAmount, lock.lockedAt);
    }

    function getCommunityEarned(address user) external view returns (uint256) {
        return _communityEarned[user];
    }

    function getAllMembersCount() external view returns (uint256) {
        return _allMembers.length;
    }

    function getMemberAtIndex(uint256 index) external view returns (address) {
        if (index >= _allMembers.length) revert InvalidIndex();
        return _allMembers[index];
    }

    function isMemberRegistered(address user) external view returns (bool) {
        return _isMemberRegistered[user];
    }

    function getTeamInfo(address user) external view returns (
        uint256 teamPerf,
        uint256 smallZonePerf,
        uint256 directCount,
        uint8 vLevel
    ) {
        teamPerf = _teamPerformance[user];
        smallZonePerf = _getSmallZonePerformance(user);
        directCount = _members[user].directReferralCount;
        vLevel = _members[user].vLevel;
    }

    // ======================== Storage Gap ========================

    uint256[49] private __gap;
}
